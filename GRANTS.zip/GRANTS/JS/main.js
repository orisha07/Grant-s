

 

function condition() {
  const info1 = document.getElementById("info1");
  const info2 = document.getElementById("info2")
  
  if(onclick = true){
    info1.style = "display:none;"
    info2.style = "display:block;"
  }else{
    condition2();
  }
}

function condition2() {
  const info1 = document.getElementById("info1");
  const info2 = document.getElementById("info2")
  
  if(onclick = true){
    info1.style = "display:none;"
    info2.style = "display:block;"
  }else{
    condition2();
  }
}



function condition3(){
  window.open("Index.html", self);
}


 
